package cn.edu.nchu.student.vo.afterclass;

public class Volunteer {
    private String st_number;
    private String st_name;
    private String date;
    private String name;
    private String score;
    private String file;

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public String getSt_number() {
        return st_number;
    }

    public void setSt_number(String st_number) {
        this.st_number = st_number;
    }

    public String getSt_name() {
        return st_name;
    }

    public void setSt_name(String st_name) {
        this.st_name = st_name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }
}
